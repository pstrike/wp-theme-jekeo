<style type="text/css">
  <?php if( !blahlab_value($blahlab_widget_ready) ):?>
    /* hide wordpress widget in customizer */
    #available-widgets-list .widget-tpl {
      display: none !important;
    }

    #available-widgets-list div[id^="widget-tpl-blahlab-widget-"] {
      display: block !important;
    }
  <?php endif; ?>

</style>