<input v-model="options.recipient" type="text" placeholder="Contact Form Recipient" />
<input v-model='options.title' type="text" placeholder="Title" />