<div class="full dark">
  <div class="row">
    <div class="large-12 large-centered columns">
      <div class="section-title">
        <div class="row">
          <div class="large-6 columns">
            <h2 class="white"><?php echo esc_html(blahlab_value($this->instance, 'options.title')) ?></h2>
          </div>
        </div>
      </div>
      <div class='form'>
        <form id='contact_form' method='POST'>
          <p id='thanks' class='hide'>
            Thanks for contacting us, we'll be in touch soon!
          </p>
          <input class='required' name='name' placeholder='NAME' type='text'>
          <input class='required email' name='email' placeholder='EMAIL' type='text'>
          <input class='required' name='subject' placeholder='SUBJECT' type='text'>
          <textarea class='required' name='message' placeholder='MESSAGE'></textarea>
          <div class='spacing'></div>
          <input type="hidden" name="action" value="blahlab_widget_ajax_contact_details">
          <input type="hidden" name="widget_action" value="send_email">
          <input type="hidden" name="widget_number" value="<?php echo esc_attr($this->number); ?>">
          <input class='button white small boxed' type='submit'>
        </form>
      </div>
    </div>
  </div>
</div>