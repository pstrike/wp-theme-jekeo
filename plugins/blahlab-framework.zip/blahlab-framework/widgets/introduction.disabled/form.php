<input type="text" v-model="options.title" placeholder="Title" />
<textarea v-model="options.text" placeholder="Text"></textarea>
<blahlab-upload-image v-model="options.image">Choose image</blahlab-upload-image>