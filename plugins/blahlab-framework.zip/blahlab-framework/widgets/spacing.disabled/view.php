<?php

  $text = blahlab_value($this->instance, 'options.text');

?>

<div class="two spacing"></div>