<?php

class Blahlab_Spacing_Widget extends Blahlab_Vue_Widget {

  public $widget_title = "Spacing";
  public $widget_id = 'spacing';
  public $post_type = '';
  public $taxonomy = '';
  public $classname = '';


  public $defaults = array(
    'text' => ''
  );

}

?>