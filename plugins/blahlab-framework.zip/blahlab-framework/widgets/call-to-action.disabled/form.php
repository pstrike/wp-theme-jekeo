<textarea v-model='options.text' type="text" placeholder="Call to action text" ></textarea>
<input type="text" v-model="options.button.text" placeholder="Button Text"></textarea>
<input type="text" v-model="options.button.url" placeholder="Button URL"></textarea>
<blahlab-color-picker v-model="options.bg_color">Select Background Color</blahlab-color-picker>